
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Tuna No Crust");
		System.out.println("The Fast and the Furious");
		System.out.println("Paul Walker");
		System.out.println(2001);

	}

}
